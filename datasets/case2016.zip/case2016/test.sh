#!/bin/bash
./bin/future_net ../test-case/case0/topo.csv ../test-case/case0/demand.csv ../test-case/case0/test.csv > ../test-case/result.csv
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> ../test-case/result.csv
./bin/future_net ../test-case/case1/topo.csv ../test-case/case1/demand.csv ../test-case/case1/test.csv >> ../test-case/result.csv
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> ../test-case/result.csv
./bin/future_net ../test-case/case2/topo.csv ../test-case/case2/demand.csv ../test-case/case2/test.csv >> ../test-case/result.csv
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> ../test-case/result.csv

lw_app="./bin/future_net"
lw_dir="../test-case/case/case"
lw_topo="/topo.csv"
lw_demand="/demand.csv"
lw_test="/test.csv"
lw_arr=(10-3 20-5 20-8 30-8 40-10 40-15 50-10 50-15 60-10 60-15 60-18 70-15 70-18 80-15 80-18 90-15 90-18 100-15 100-18 120-18 140-18 150-18 150-20 180-20 180-22 200-20 200-22 220-20 220-22 240-20 260-22 260-25 280-23 280-25 300-23 300-25 300-27 320-25 320-27 340-25 340-27 360-27 360-29 380-28 380-30 400-28 400-30 420-30 420-32 440-32 440-34 460-34 460-36 480-36 480-38 500-38 500-40 500-42 520-40 520-44 560-44 560-46 580-46 580-48 600-20 600-30 600-40 600-48 600-50)
lw_num=(/case1 /case2 /case3 /case4 /case5 /case6 /case7 /case8 /case9)
for var in ${lw_arr[@]}
do
	for vn in ${lw_num[@]}
	do
		echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> ../test-case/result.csv
		echo 输入文件:${lw_app} ${lw_dir}${var}${vn}${lw_topo} ${lw_dir}${var}${vn}${lw_demand} ${lw_dir}${var}${vn}${lw_test} >> ../test-case/result.csv
	${lw_app} ${lw_dir}${var}${vn}${lw_topo} ${lw_dir}${var}${vn}${lw_demand} ${lw_dir}${var}${vn}${lw_test} >> ../test-case/result.csv
	done
done
